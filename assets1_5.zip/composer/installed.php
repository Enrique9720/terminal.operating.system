<?php return array(
    'root' => array(
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => NULL,
        'name' => '__root__',
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => NULL,
            'dev_requirement' => false,
        ),
        'picqer/php-barcode-generator' => array(
            'pretty_version' => 'v2.2.4',
            'version' => '2.2.4.0',
            'type' => 'library',
            'install_path' => __DIR__ . '/../picqer/php-barcode-generator',
            'aliases' => array(),
            'reference' => 'b98f110cc5a79f723688fb17fd90b9325300d844',
            'dev_requirement' => false,
        ),
    ),
);
