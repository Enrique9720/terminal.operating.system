<?php    
class Flickr { 

    private $apiKey;
    private $userId;
    public function __construct($apikey = null, $userid = null) {
        $this->apiKey = $apikey;
        $this->userId = $userid;
    } 
 
    public function search($query = null, $per_page = 50, $format = 'php_serial') { 
        $args = array(
            'method' => 'flickr.photos.search',
            'api_key' => $this->apiKey,
            'text' => urlencode($query),
            'privacy_filter' => 2,
            'user_id' => $this->userId,
            'per_page' => $per_page,
            'format' => $format
        );
        $url = 'http://flickr.com/services/rest/?'; 
        $search = $url.http_build_query($args);
        $result = $this->file_get_contents_curl($search); 
        if ($format == 'php_serial') $result = unserialize($result); 
        return $result; 
    } 
 
    private function file_get_contents_curl($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36');
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        $data = curl_exec($ch);
        $retcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($retcode == 200) {
            return $data;
        } else {
            return null;
        }
    }
}
?>
